import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccountInfoService } from '../../services/account-info.service';
import { AuthService } from '../../services/auth.service';
import { NavbarService } from '../../services/navbar.service';
import { SignalRService } from '../../services/signal-r.service';
import { Subscription } from 'rxjs';
import { UrlSegmentEnum } from '../../navigation/url-segment-enum';
import { UserRoleEnum } from '../../model/user-role-enum';

// eslint-disable-next-line new-cap
@Component({
  selector: 'app-nav-menu',
  templateUrl: './nav-menu.component.html',
  styleUrl: './nav-menu.component.scss'
})
export class NavMenuComponent{
  public navDrawerVisible: boolean = false;
  public navDrawerUser: boolean = false;
  public Enrollment: boolean = false;
  public System: boolean = false;
  public Mobile: boolean = false;
  public Messages: boolean = false;
  public Client_Admin: boolean = false;
  public User: boolean = false;
  public UserEnrollment: boolean = false;
  public UserSystem: boolean = false;
  public userMobile: boolean = false;
  public EnrollmentDetails: boolean = false;
  public value: string = '1';

  constructor() {
  }

  toggleChildNavDrawer(navDrawerVisibleIndex: number) {
    switch (navDrawerVisibleIndex) {
    case 0:
      this.navDrawerVisible = false;
      break;
    case 1:
      this.navDrawerUser = false;
      break;
    case 2:
      this.Enrollment= false;
      break;
    case 3:
      this.System = false;
      break;
    case 4:
      this.Mobile = false;
      break;
    case 5:
      this.Messages = false;
      break;
    case 6:
      this.Client_Admin = false;
      break;
    case 7:
      this.User = false;
      break;
    case 8:
      this.UserEnrollment = false;
      break;
    case 9:
      this.UserSystem = false;
      break;
    case 10:
      this.userMobile = false;
      break;
    case 11:
      this.EnrollmentDetails = false;
      break;
      // Add cases for other child nav-drawers as needed
    default:
      break;
    }
  }

}
